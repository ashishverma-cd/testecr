# sample-node-app

A Helm chart for deploying a simple Node.js Hello World application with NGINX.

## Features

- Node.js Hello World app
- Configurable with `values.yaml`
- NGINX reverse proxy
- Lightweight and easy to deploy

## Installation

```bash
helm repo add testecr https://akonverma97.github.io/testecr
helm install myapp testecr/sample-node-app

## Configuration

You can customize this chart by overriding the default settings in `values.yaml`.

Below are the available configuration options:

| Parameter             | Description                                              | Default                                              |
|----------------------|----------------------------------------------------------|------------------------------------------------------|
| `image.repository`    | Docker image repository                                 | `dkr.ecr.us-east-1.amazonaws.com/testecr` |
| `image.tag`           | Docker image tag                                        | `latest`                                             |
| `image.pullPolicy`    | Image pull policy                                       | `IfNotPresent`                                       |
| `imagePullSecrets`    | Secrets to pull image from private registry             | `[ { name: ecr-secret } ]`                           |
| `service.type`        | Kubernetes Service type (`ClusterIP`, `LoadBalancer`)   | `ClusterIP`                                          |
| `service.port`        | Port exposed by the service                             | `80`                                                 |
| `service.containerPort` | Port your app runs on inside the container           | `3000`                                               |
| `ingress.enabled`     | Enable or disable ingress                               | `true`                                               |
| `ingress.hosts`       | List of ingress hosts                                   | `[ your-domain.com ]`                                |
| `ingress.tls`         | TLS configuration for ingress                           | `[]`                                                 |

### 🚀 Install with Custom Values

To install using your own custom values:

```bash
helm install myapp testecr/sample-node-app -f my-values.yaml

